function [ dVx, dVy ] = perturbation( magV, theta )
% perturbation() returns the x and y components of the perturbation based
% on the magnitude desired. 
% 
% function call:
% [ dVx, dVy ] = perturbation( magV, theta )
% 
% Inputs:
% magV  = the magnitude of the velocity to be split into x and y
%         perturbations 
% theta = angle of the velcoity relative to the earth so that the
%         perturbation velocities returned are in the same as the ram
%         direction of the spacecraft velocity. This input is in degrees
% 
% Outputs: its obvious by the function call
% 
% written 1/30/2018 Aaron Aboaf
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Determine the perurbations based on geometry
dVx = magV*cosd(theta);
dVy = magV*sind(theta);
end

