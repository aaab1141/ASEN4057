function [ state_changes ] = orbit_equations( t,state )
% orbit_equations() is designed to work with the ODE solver such that a
% three body orbits problem is solved with the equations which output the
% state_changes of the three bodies.
% 
% Function call
% [ state_changes ] = orbit_equations( t,state )
% 
% INPUT --> state - which includes:
% Me    = Mass of the earth
% Mm    = Mass of the moon
% Ms    = Mass of the spacecraft
% Xs    = x position of the spacecraft
% Ys    = y position of the spacecraft
% Xm    = x position of the Moon
% Ym    = y position of the Moon
% (the position of the Earth is assumed as (0,0) and to be inertial for all time
% Vsx   = x velocity of the s/c
% Vsy   = y velocity of the s/c
% Vmx   = x velocity of the Moon
% Vmy   = y velocity of the Moon
% (the velocity of the Earth is assumes as [0,0] and to be inertial for all time
% 
% state = [ Me,Mm,Ms,Xs,Ys,Xm,Ym,Vsx,Vsy,Vmx,Vmy ]
% 
% OUTPUTS:
% state_changes = a column vector which works with the ODE functions to
%                 track the changing state variables. Each entry to the
%                 state_changes variable is called out in the body of the
%                 function explicitly
% 
% Written  1/29/2018  Aaron Aboaf
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Calculate the forces acting on the spacecraft, moon, and the Earth
Me = state(1);
Mm = state(2);
Ms = state(3);
Xs = state(4);
Ys = state(5);
Xm = state(6);
Ym = state(7);
[ Fesx,Fesy ] = gforce(0,0,Xs,Ys,Me,Ms); %earth and s/c
[ Femx,Femy ] = gforce(0,0,Xm,Ym,Me,Mm); %earth and moon
[ Fsmx,Fsmy ] = gforce(Xs,Ys,Xm,Ym,Ms,Mm); %s/c and moon

% Calcualte the accelerations of each of the bodies based on the masses and
% forces acting on them, which happen to be The differential Equations that
% will govern the three body problem
% % % % Asx = (Fmsx+Fesx)/Ms; %s/c acceleration in x
% % % % Asy = (Fmsy+Fesy)/Ms; %s/c acceleration in y
% % % % Amx = (Femx+Fsmx)/Mm; %moon acceleration in x
% % % % Amy = (Femy+Fsmy)/Mm; %moon acceleration in y
% % % % Aex = 0; %Earth acceleration in x (inertial for all time)
% % % % Aey = 0; %Earth acceleration in y (inertial for all time)
% % % % 
% % % % % The differential Equations that will govern the three body problem
% % % % dVsx = Asx;
% % % % dVsy = Asy;
% % % % dVmx = Amx;
% % % % dVmy = Amy;
% % % % dVex = Aex;
% % % % dVey = Aey;
% For velocity integration
% % % % dVsx = (Fmsx+Fesx)/Ms; %s/c acceleration in x
% % % % dVsy = (Fmsy+Fesy)/Ms; %s/c acceleration in y
% % % % dVmx = (Femx+Fsmx)/Mm; %moon acceleration in x
% % % % dVmy = (Femy+Fsmy)/Mm; %moon acceleration in y
% % % % dVex = 0; %Earth acceleration in x (inertial for all time)
% % % % dVey = 0; %Earth acceleration in y (inertial for all time)
% % % % 
% % % % dXs = Vsx; 
% % % % dYs = Vsy;
% % % % dXm = Vmx;
% % % % dYm = Vmy;
% % % % dXe = Vex;
% % % % dYe = Vey;

% Reassign to state_changes vector for output
% Remember that state_changes = [ Me,Mm,Ms,Xs,Ys,Xm,Ym,Vsx,Vsy,Vmx,Vmy ]
state_changes = zeros(11,1); %initialize state vector
state_changes(4) = state(8); %pass s/c x velocity to s/c x position derivative
state_changes(5) = state(9); %pass s/c y velocity to s/c y position derivative
state_changes(6) = state(10); %pass Moon x velocity to Moon x position derivative
state_changes(7) = state(11); %pass Moon y velocity to Moon y position derivative
state_changes(8) = (-Fsmx+Fesx)/Ms; %s/c acceleration in x to the x velocity derivative
state_changes(9) = (-Fsmy+Fesy)/Ms; %s/c acceleration in y to the y velocity derivative
state_changes(10) = (Femx+Fsmx)/Mm; %moon acceleration in x to the x velocity derivative
state_changes(11) = (Femy+Fsmy)/Mm; %moon acceleration in y to the y velocity derivative

end

