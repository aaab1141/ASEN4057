function [ f ] = OptFunction( mag_dV,theta,smooth,~ )
% Optimization function for fmincon()
% Written  2/1-9/2018 Aaron Aboaf && Brandon Sundahl (all rights reserved)
% 
% 
% 
Mm = 7.34767309*10^22; %kg Mass of Moon
Me = 5.97219*10^24; %kg mass of Earth
Msc = 28333; % kg Mass of Spacefcraft
% rm = 1737100; % m Radius of Moon
% re = 6371000; % m Radius of Earth
G = 6.674*10^(-11); % N.m^2/kg^2 Gravitational Constant

% Define Relational Initial Conditions
d_es = 338000000; % m Distance from CoE to s/c
d_em = 384403000; % m distance from Earth to Moon
Vi_s = 1000; % m/s velocity of s/c just after explosion
theta_s = 50; % degrees angle of the s/c
theta_m = 42.5; % degrees angle of the Moon

% Define the speed of the moon
Vi_m = sqrt(G*Me^2/((Me+Mm)*d_em)); %initial speed of the moon

% Define Initial State Vector
% Spacecraft
Xs = d_es*cosd(theta_s); %initial x position of the spacecraft
Ys = d_es*sind(theta_s); %initial y position of the spacecraft
Vsx0 = Vi_s*cosd(theta_s); %initial x velocity of the spacecraft BEFORE delta V
Vsy0 = Vi_s*sind(theta_s); %initial y velocity of the spacefract BEFORE delta V
% Moon
Xm = d_em*cosd(theta_m); %initial x position of the moon
Ym = d_em*sind(theta_m); %initial y position of the moon
Vmx = -Vi_m*sind(theta_m); %initial x velocity of the moon
Vmy = Vi_m*cosd(theta_m); %initial y velcotiy of the moon
% Earth
% Xe = 0; %initial x position of the Earth (for all time)
% Ye = 0; %initial y position of the Earth (for all time)
% Vex = 0; %initial x velocity of the Earth (for all time)
% Vey = 0; %initial y velocity of the Earth (for all time)

% Define the perturbed velocity the spacecraft
[ dVx, dVy ] = perturbation(mag_dV,theta); %perturbation velocities
% fprintf('%f \n',[mag_dV])
Vsx = Vsx0 + dVx; %old V + delta Vx
Vsy = Vsy0 + dVy; %old V + delta Vy

% Assemble the initial state vector
state = [ Me,Mm,Msc,Xs,Ys,Xm,Ym,Vsx,Vsy,Vmx,Vmy ];

% define Time Span for integration
tspan = [0,1e6];
options = odeset('Events',@myevents,'RelTol',1e-4);

% integrate
[t,traj,te,~,~] = ode45(@(t,traj)orbit_equations(t,traj),tspan,state,options);
[ ~, ~, ~, thecase ] = myevents( t,traj(end,:) );

%set the event case identifiers
if thecase == 1 %moon crash
    f = 1e200;
%     fprintf('moon crash\n')
elseif thecase == 2 %earth success
    f = te;
%     fprintf('\t\tyay hit the earth\n')
else
    f = 1e20; %void fail
%     fprintf('\t\t\t\t something else\n')
end
end

