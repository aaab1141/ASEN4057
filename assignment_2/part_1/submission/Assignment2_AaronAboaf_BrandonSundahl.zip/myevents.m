function [ value, isterminal, direction, thecase ] = myevents( t,traj )
% An event happens when value = 0
% Event one: crashing into moon
Xs = traj(4); %s/c x position
Ys = traj(5); %s/c y position
Xm = traj(6); %moon x position
Ym = traj(7); %moon y position

d_ms  = euclidian_distance(Xm,Ym,Xs,Ys) - 1.7371e6; %distance from moon to s/c
d_em2 = euclidian_distance(0,0,Xs,Ys) - 2*euclidian_distance(Xm,Ym,0,0); %twice the distance from the earth to the moon
d_es = euclidian_distance(Xs,Ys,0,0) - 6371e3; %distance from earth to spacecraft

value = [d_es; d_ms; d_em2];

isterminal = [1;1;1];
direction = [-1;-1;-1];

if d_ms <= 1 && d_ms > -1
    thecase = 1; %moon case
elseif d_es <= 1 && d_es > -1
    thecase = 2; %earth case
elseif d_em2 <= 0
    thecase = 3; %void case
else
    thecase = 0; %keep going case
end

end

