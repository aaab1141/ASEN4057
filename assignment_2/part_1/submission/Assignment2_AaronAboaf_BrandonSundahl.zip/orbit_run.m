function [ thecase ] = orbit_run( state )
% Simply returns the case event of the calculated orbit
% Written  2/1-9/2018 Aaron Aboaf && Brandon Sundahl (all rights reserved)

tspan = [0,1e6];
options = odeset('Events',@myevents, 'RelTol',1e-12);

[t,traj,~,~,~] = ode45(@(t,traj)orbit_equations(t,traj),tspan,state,options);
[ ~, ~, ~, thecase ] = myevents( t,traj(end,:) );

end

