function [ d ] = euclidian_distance( x1,y1,x2,y2 )
% euclidian_distance() returns the Euclidian distance between two points
% (x1,y1) and (x2,y2).
% 
% function call
% [ d ] = euclidian_distance( x1,y1,x2,y2 )
% 
% written  1/29/2018 Aaron Aboaf
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
d = sqrt((x1-x2).^2+(y1-y2).^2); %calculate the distance
end

