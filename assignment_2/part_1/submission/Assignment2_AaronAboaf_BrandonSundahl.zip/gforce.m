function [ Fx,Fy ] = gforce( Xa,Ya,Xb,Yb,Ma,Mb )
% gforce() calculates the fore acting between two bodies X and Y over a
% distance, D, separating them. Assumes the newtonian gravitational
% constant.
% 
% function call:
% [ Fx,Fy ] = gforce( Xa,Ya,Xb,Yb )
% 
% inputs:
% Xa,Ya  = the x and y positions of the A body (meters)
% Xb,Yb  = the x and y positions of the B body (meters)
% Ma,Mb  = Masses of the bodies (kg)
% 
% written 1/29/2018  Aaron Aboaf
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Define the gravitational constant
G = 6.674*10^(-11); %N.m^2/kg^2

% Calculate the distance between the bodies based on their coordinates
D = euclidian_distance(Xa,Ya,Xb,Yb);

% Calculate the force in the X direction
Fx = G*Ma*Mb*(Xa-Xb)/(D^3);

% Calculate the force in the Y direction
Fy = G*Ma*Mb*(Ya-Yb)/(D^3);
end
