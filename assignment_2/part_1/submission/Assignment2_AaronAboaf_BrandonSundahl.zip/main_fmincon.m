% This is the main script for ASEN 4057 Assignment 2
% Written  2/1-9/2018 Aaron Aboaf && Brandon Sundahl (all rights reserved)
% 
% This script used the MATLAB function minimization toolbox to calculate
% the minimum delta V required and at what angle it should be fired for a
% stranded spacecraft on a collision course with the moon. It uses a custom
% designed algorithm to identify a reasonable constraint window for the
% constrained minization function to search for the minimum. In the script
% below, the algorithm is part of section 1. Section 2 performs several
% constrained minizations across a range of initial guesses to ensure that
% the minimum time is found. It turns out that the surface being minimized
% has many local minimums thus making it imperative that several inital
% guesses are made across the reasonable region such that a true minimum can
% be calculated from the simulations.
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%Housekeeping
clear; close all; clc

% Define Celestial Body Properties 
Mm = 7.34767309*10^22; %kg Mass of Moon
Me = 5.97219*10^24; %kg mass of Earth
Msc = 28333; % kg Mass of Spacefcraft
rm = 1737100; % m Radius of Moon
re = 6371000; % m Radius of Earth
G = 6.674*10^(-11); % N.m^2/kg^2 Gravitational Constant

% Define Relational Initial Conditions
d_es = 338000000; % m Distance from CoE to s/c
d_em = 384403000; % m distance from Earth to Moon
Vi_s = 1000; % m/s velocity of s/c just after explosion
theta_s = 50; % degrees angle of the s/c
theta_m = 42.5; % degrees angle of the Moon

% Define the speed of the moon
Vi_m = sqrt(G*Me^2/((Me+Mm)*d_em)); %initial speed of the moon

% Define Initial State Vector properties except for the initial velocity
% which needs to be calculated after the delta v is divided into x and y
% components.
% Spacecraft
Xs = d_es*cosd(theta_s); %initial x position of the spacecraft
Ys = d_es*sind(theta_s); %initial y position of the spacecraft
Vsx0 = Vi_s*cosd(theta_s); %initial x velocity of the spacecraft BEFORE delta V
Vsy0 = Vi_s*sind(theta_s); %initial y velocity of the spacefract BEFORE delta V
% Moon
Xm = d_em*cosd(theta_m); %initial x position of the moon
Ym = d_em*sind(theta_m); %initial y position of the moon
Vmx = -Vi_m*sind(theta_m); %initial x velocity of the moon
Vmy = Vi_m*cosd(theta_m); %initial y velcotiy of the moon
% Earth
Xe = 0; %initial x position of the Earth (for all time)
Ye = 0; %initial y position of the Earth (for all time)
Vex = 0; %initial x velocity of the Earth (for all time)
Vey = 0; %initial y velocity of the Earth (for all time)

%% Constraint Optimization -- Deciding what the fmincon() bounds should be
% Identify a constraint range that is acceptable for finding the
% appropriate constraint ranges for fmincon. This determination will be
% based on a rough sweep of a larger region identified by the user using
% the mfile: main_for_integration_testing.m which is just an easy way to
% the user to input different velocites and angles to see what the
% trajectory does.

ari = 75; %initial starting point for the angle
dvi = 85; %initial statting point for the delta V

%intial tol and setpoint values to intiate the while loop
setpoint = 1; %choose setpoint which will deterimine the end condition of the while loop for constraint optimzation
itermax = 50; %choose the maximum number of constrain optimzation interations to run
tol = setpoint + itermax; %set inital tolerance high so that the while loop executes on the first run
lecount = 1; %track the number of times the constraint optimizer algorithm finds a trajectory that hits the earth
earthcon = 0; %earth condition for use within the while optimzation loop. 
% earthcon is needed to execute a recursive part of the algorithm within the optimization loop
while tol > setpoint
    if setpoint == 1 %calculates the initail dV , not used after the first iteration of the constrain optimizer
        [ dVx, dVy ] = perturbation(dvi,ari); %perturbation velocities
        setpoint = 2; %ensrues this is not executed again
    end
    
    Vsx = Vsx0 + dVx; %old V + delta Vx
    Vsy = Vsy0 + dVy; %old V + delta Vy
    % Assemble the initial state vector
    state = [ Me,Mm,Msc,Xs,Ys,Xm,Ym,Vsx,Vsy,Vmx,Vmy ];
    %integrate to see what we hit
    thecase = orbit_run(state);
    
    if thecase == 1 && earthcon == 0%if we hit the moon
        % if we hit the moon then two things need to change: either we need
        % more dv or our angle needs to be closer to 90 degrees in order to
        % boost us past the moon so that we can slingshot around it
        newdV = dvi + 1; %iterate on the dV so that we increase (same idea for next 3 lines)
        dvi = newdV;
        newtheta = ari + 1;
        ari = newtheta;
    elseif thecase == 3 || thecase == 0 %if we smash into the void or the integration stops
        % if we smash into the void then the dV is too strong of the angle
        % is too big, thus we need to make it less
        newdV = (dvi - dvi/2); %iterate on the dV so that we decrease (same idea for next 3 lines)
        dvi = newdV;
        newtheta = (ari - ari/2);
        ari = newtheta;
    elseif earthcon == 0 && thecase == 2 %if we hit the earth
        % we are looking to refine the minimums of each that make us hit
        % the earth so we will use this to actually shrink the change
        % every time it hits the earth so that we are able to approach the
        % limit with a bit of accuracy behind it
        lecount = lecount + 1; %identify that we hit the earth to track the iterations and evetually end the while loop
        
        % Make much smaller changes to the magdV and theta to fine tune the
        % dV and theta ranges that hit the earth
        dvi1 = dvi + dvi*.01; 
        ari1 = ari + ari*.01;
        dvi2 = dvi - dvi*.01;
        ari2 = dvi - dvi*.01;
        
        % set up another TWO integrations for checking
        [ dVx, dVy ] = perturbation(dvi1,ari1); %first (higher) perturbation velocities
        Vsx = Vsx0 + dVx; %old V + delta Vx
        Vsy = Vsy0 + dVy; %old V + delta Vy
        
        % Assemble the first (higher) initial state vector
        state1 = [ Me,Mm,Msc,Xs,Ys,Xm,Ym,Vsx,Vsy,Vmx,Vmy ];
    
        [ dVx, dVy ] = perturbation(dvi2,ari2); %second (lower) perturbation velocities
        Vsx = Vsx0 + dVx; %old V + delta Vx
        Vsy = Vsy0 + dVy; %old V + delta Vy
        
        % Assemble the second (lower) initial state vector
        state2 = [ Me,Mm,Msc,Xs,Ys,Xm,Ym,Vsx,Vsy,Vmx,Vmy ];
        
        %test each case beginning with state 2 because thats more likely to
        %be hitting the moon than state 1 cause its going to be less
        thecase2 = orbit_run(state2);
        if thecase2 == 1 %if hit moon try we need to try thi higher state which is state 1
            thecase1 = orbit_run(state1);
            if thecase1 == 0 || thecase1 == 3 %if we go to the time limit or hit the void condition
                tol = .01; %end the while loop meaning we found the higher limit
            else
                dvi = dvi1; %send the new magdV and theta back through the recursive part of the algorithm 
                ari = ari1;
                earthcon = 1; %sends values to the recursive part of the alogrithm
            end
                
        else
            tol = itermax/lecount; % recalculate the tolerance to see if we have been through the while loop enough time
            dvi = dvi2; %send the new magdV and theta back through the algorithm, not the recursive part yet though
            ari = ari2; %these basically bring the elocites back down until we find the increase thats required for the recursive part of the algorithm
        end
    %%%%% RECURSIVE PART REQUIREING earthcon form above %%%%%%%%%    
    elseif earthcon == 1 %earthcon activated
        lecount = lecount + 1; %continue to make sure we drop the tolerance so that we can exit the while loop
        
        % Again create split cases for checking
        dvi1 = dvi + dvi*.01;
        ari1 = ari + ari*.01;
        dvi2 = dvi - dvi*.01;
        ari2 = dvi - dvi*.01;
        
        [ dVx, dVy ] = perturbation(dvi1,ari1); %first (higher) perturbation velocities
        Vsx = Vsx0 + dVx; %old V + delta Vx
        Vsy = Vsy0 + dVy; %old V + delta Vy
        % Assemble the first (higher) initial state vector
        state1 = [ Me,Mm,Msc,Xs,Ys,Xm,Ym,Vsx,Vsy,Vmx,Vmy ];
    
        [ dVx, dVy ] = perturbation(dvi2,ari2); %second (lower) perturbation velocities
        Vsx = Vsx0 + dVx; %old V + delta Vx
        Vsy = Vsy0 + dVy; %old V + delta Vy
        % Assemble the second (lower) initial state vector
        state2 = [ Me,Mm,Msc,Xs,Ys,Xm,Ym,Vsx,Vsy,Vmx,Vmy ];
        
        % Below is the same test except we will run through this enouth t
        % exit the while loop and thus find the optimized constrataints for
        % the fmincon() optimization
        thecase2 = orbit_run(state2);
        if thecase2 == 1 %if hit moon try higher
            thecase1 = orbit_run(state1);
            if thecase1 == 0 || thecase1 == 3 %if we go to the time limit or hit the void condition
                tol = .01; %end the while loop
            else
                dvi = dvi1; %bring the conditions back into the recursive part of the function
                ari = ari1;
            end
        else %move lower back towards what will be the lower end of the constraint window
            tol = itermax/lecount;
            dvi = dvi2;
            ari = ari2;
        end
    end
%     fprintf('%f\n',tol) % uncomment to see the tolerance value after each iteration
end

%% Run the constrained optimization for the minimum delta V
% Option Parameters
smooth = 1;

% Define the Desired End Position
P_end = 0; % Center of the Earth

% set a range of initial conditions. these values are based off the
% constraints above and some manual plug and play in a separate script that
% integrates and plots one trajectory for testing integration
V = linspace(78,100,20);
T = linspace(88,90,20);

% set the minimum and maximum conditions for the fmincon() optimization.
% Notice that the minumum values are defined WRT to the optimization that
% happens in section 1
vecmin = [dvi-4,ari];
vecmax = [V(20),T(20)]; %defined by the problem as the maximums

% Optimize to find minimum |Delta V|
ig0 = [V(8),T(11)];
[vec1,fval1] = fmincon(@(vec)OptFunction(vec(1),vec(2),smooth,P_end),ig0,[],[],[],[],vecmin,vecmax);

ig0 = [V(6),T(10)];
[vec2,fval2] = fmincon(@(vec)OptFunction(vec(1),vec(2),smooth,P_end),ig0,[],[],[],[],vecmin,vecmax);

ig0 = [V(10),T(16)];
[vec3,fval3] = fmincon(@(vec)OptFunction(vec(1),vec(2),smooth,P_end),ig0,[],[],[],[],vecmin,vecmax);

ig0 = [V(2),T(3)];
[vec4,fval4] = fmincon(@(vec)OptFunction(vec(1),vec(2),smooth,P_end),ig0,[],[],[],[],vecmin,vecmax);

ig0 = [V(2),T(16)];
[vec5,fval5] = fmincon(@(vec)OptFunction(vec(1),vec(2),smooth,P_end),ig0,[],[],[],[],vecmin,vecmax);

ig0 = [V(12),T(3)];
[vec6,fval6] = fmincon(@(vec)OptFunction(vec(1),vec(2),smooth,P_end),ig0,[],[],[],[],vecmin,vecmax);

ig0 = [V(12),T(16)];
[vec7,fval7] = fmincon(@(vec)OptFunction(vec(1),vec(2),smooth,P_end),ig0,[],[],[],[],vecmin,vecmax);

% From the value returns of the functions above, the time value will be
% associated with the shortest burn so we will identify the intial
% conditions that result in the desired return trajectories
vals = [fval1,fval2,fval3,fval4,fval5,fval6,fval7];
[themin, minindex] = min(vals);

allvecs = [vec1;vec2;vec3;vec4;vec5;vec6;vec7];
ig0 = allvecs(minindex,:);

%calcualte the final dVs
% It was discovered that a small boost in velocity was needed to actually
% clear the moon, this is true in all the cases so the small attition
% (.4m/s) is hard coded in at this stage.
[ dVx, dVy ] = perturbation(ig0(1)+.4,ig0(2)); %perturbation velocities
Vsx = Vsx0 + dVx; %old V + delta Vx
Vsy = Vsy0 + dVy; %old V + delta Vy

% Assemble the final initial state vector
state = [ Me,Mm,Msc,Xs,Ys,Xm,Ym,Vsx,Vsy,Vmx,Vmy ];

% define Time Span for integration
tspan = [0,1e6];
options = odeset('Events',@myevents, 'RelTol',1e-12);

[t,traj,te,ye,ie] = ode45(@(t,traj)orbit_equations(t,traj),tspan,state,options);
% [ ~, ~, ~, thecase ] = myevents( t,traj(end,:) );

% Plot the final trajectory
figure; hold on
plot(traj(:,4),traj(:,5),'r',traj(:,6),traj(:,7),'k') %plot the s/c trajectory
grid on; title(['Final Trajectory: \Delta V = ',num2str(ig0(1)),'m/s & \Theta = ',num2str(ig0(2)),'^o'])
moon_sphere([traj(end,6),traj(end,7)],'m')
earth_sphere('m')
view([0,90])
