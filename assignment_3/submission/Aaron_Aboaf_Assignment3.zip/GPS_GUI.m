function varargout = GPS_GUI(varargin)
% GPS_GUI MATLAB code for GPS_GUI.fig
%      GPS_GUI, by itself, creates a new GPS_GUI or raises the existing
%      singleton*.
%
%      H = GPS_GUI returns the handle to a new GPS_GUI or the handle to
%      the existing singleton*.
%
%      GPS_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GPS_GUI.M with the given input arguments.
%
%      GPS_GUI('Property','Value',...) creates a new GPS_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GPS_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GPS_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GPS_GUI

% Last Modified by GUIDE v2.5 14-Feb-2018 10:11:58

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GPS_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @GPS_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GPS_GUI is made visible.
function GPS_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GPS_GUI (see VARARGIN)

% Choose default command line output for GPS_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
set(handles.animation_button,'Enable','off')
set(handles.animation_button,'BackgroundColor',[1,0,0])


% UIWAIT makes GPS_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GPS_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


%%%% Initializations %%%%
% --- Executes during object creation, after setting all properties.
function Amount_value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Amount_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.
function Fi_value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Fi_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.
function Fs_value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Fs_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.
function PRN_value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PRN_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.
function ms_to_avg_value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ms_to_avg_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function animation_button_CreateFcn(hObject, eventdata, handles)
% hObject    handle to animation_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Callbacks %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Process_Data_Button.
function Process_Data_Button_Callback(hObject, eventdata, handles)
% hObject    handle to Process_Data_Button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% close all %close any figures that are still open

% set the anumate button to gray if its not already
set(handles.animation_button,'Enable','off')
set(handles.animation_button,'BackgroundColor',[1,0,0])
drawnow

% Aquire the user input values
PRN = PRN_value_Callback(hObject,eventdata,handles);
Fs = Fs_value_Callback(hObject,eventdata,handles);
Fi = Fi_value_Callback(hObject,eventdata,handles);
Amount = Amount_value_Callback(hObject,eventdata,handles);

% use the find_and_track function (modified from findandtrack.m) to get some data
[e_i,e_q,p_i,p_q,l_i,l_q,carrierfq,codefq]=find_and_track(PRN,Amount,Fs,Fi,handles);
plotresults_FCN(e_i,e_q,p_i,p_q,l_i,l_q,carrierfq,codefq,handles)

% set the aniimate button to green so user knows its ready
set(handles.animation_button,'BackgroundColor',[0,1,0])
set(handles.animation_button,'Enable','on')


function [PRN]=PRN_value_Callback(hObject, eventdata, handles)
% hObject    handle to PRN_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PRN_value as text
%        str2double(get(hObject,'String')) returns contents of PRN_value as a double
PRN = str2double(get(handles.PRN_value,'String'));

function [Fs]=Fs_value_Callback(hObject, eventdata, handles)
% hObject    handle to Fs_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Fs_value as text
%        str2double(get(hObject,'String')) returns contents of Fs_value as a double
Fs = str2double(get(handles.Fs_value,'String'));

function [Fi]=Fi_value_Callback(hObject, eventdata, handles)
% hObject    handle to Fi_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Fi_value as text
%        str2double(get(hObject,'String')) returns contents of Fi_value as a double
Fi = str2double(get(handles.Fi_value,'String'));

function [Amount]=Amount_value_Callback(hObject, eventdata, handles)
% hObject    handle to Amount_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Amount_value as text
%        str2double(get(hObject,'String')) returns contents of Amount_value as a double
Amount = str2double(get(handles.Amount_value,'String'));

function [ms_to_avg]=ms_to_avg_value_Callback(hObject, eventdata, handles)
% hObject    handle to ms_to_avg_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ms_to_avg_value as text
%        str2double(get(hObject,'String')) returns contents of ms_to_avg_value as a double
ms_to_avg = str2double(get(handles.ms_to_avg_value,'String'));

% --- Executes on button press in animation_button.
function animation_button_Callback(hObject, eventdata, handles)
% hObject    handle to animation_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ms_to_avg = ms_to_avg_value_Callback(hObject,eventdata,handles);

% run corrplot to get the animation
handles=corrplot_FCN(ms_to_avg,handles);
