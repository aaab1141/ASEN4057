function [ handles ] = contwrite( handles, newstring )
% Custom function to store and write more lines of text to the static text
% box in a GUI. Stores 3 lines of text to a variable in the handles
% structure. If no initial storage in the structure is present this
% function will create one. Strings input should only be the text you want.
% Each input will be a new line in the static text box

if isfield(handles,'MyString') == 0 %if there is no 'MyString' in handles singaling that this would be the first string to output
    handles.MyString = {newstring};
    set(handles.RunStatus_Text,'String',handles.MyString{1}) %output the string to the RunStatus_Text handles static text box
    drawnow %update the textbox in realtime
else %if there are already strings that exist
    marks = size(handles.MyString,2); %find how many lines are there already
    if marks == 1 %if only one previous line
        ns = {handles.MyString{1,:},newstring}; %add new string to end
        handles.MyString = ns; %store the longer string
        set(handles.RunStatus_Text,'String',sprintf([ns{1},'\n',ns{2},'\n'])) %output the string to the RunStatus_Text handles static text box
        drawnow %update the textbox in realtime 
    elseif marks == 2 %if only 2 previous lines
        ns = {handles.MyString{1,:},newstring}; %add new string to end
        handles.MyString = ns; %store the longer string
        set(handles.RunStatus_Text,'String',sprintf([ns{1},'\n',ns{2},'\n',ns{3},'\n'])) %output the string to the RunStatus_Text handles static text box
        drawnow %update the textbox in realtime
    elseif marks > 2 %if more than two strings
        cs = handles.MyString(2:end); %cut away the first string
        ns = {cs{1},cs{2},newstring}; %make the new three line string
        handles.MyString = ns; %store the new string
        set(handles.RunStatus_Text,'String',sprintf([ns{1},'\n',ns{2},'\n',ns{3},'\n'])) %output the string to the RunStatus_Text handles static text box
        drawnow %update the textbox in realtime
    else
        error('Need to add ''\\n''s to your strings')
    end
end
end

