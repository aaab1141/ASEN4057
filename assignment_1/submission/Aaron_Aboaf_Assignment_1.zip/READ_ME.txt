Simply open the script files named 
Problem_1, Problem_2, Problem_3, and Problem_BONUS and hit run. 

Follow prompts as necessary.

NOTE:
The bonus problem is set up to take actual students names so that
one does not have to do the work of matching names to numbers manually.
The function counts the number of names within the function and behaves
accordingly to assign a group of three or not.