% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% ASEN 4057 -- Assignment #1 -- Problem 2
% 
% This is the main script for Problem 2 which is a linear application of
% the Least Squares Method. The purpose of this script is to facilitate the
% implementation of the problem and showcase the modular functions
% developed for this application.
% 
% Written:  Aaron Aboaf   1/23/2017 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Housekeeping
clear; close all; clc

% Define the data inputs
x = [-5 -2 0 2 3 5 7 9 14]; %angle of attack data
y = [-.008 -.003 .001 .005 .007 .006 .009 .0145 .019]; %Cl data

% Calculate the Least Squares line of best fit with slope m and intercept b
[ m,b ] = LS_line( x,y );

% Create a set of data points with identical AoA values but on the Least
% Squares line
Y = m*x + b; %simple equation of a line

% Plot the data points and the line of best fit together
figure
plot(x,y,'-o',x,Y,'-o'); grid on
title('F-117 Nighthawk Wind Tunnel Experiment')
xlabel('Angle of Attack (^o)')
ylabel('Coefficient of Lift c_l')
legend({'Measured Data','Least Squares Fit'})
axis([min(x)-1,max(x)+1,min(Y)-.01,max(Y)+.01])
text(x(4),Y(4),['\leftarrow m = ',num2str(m,2),' & b = ',num2str(b,2)])
