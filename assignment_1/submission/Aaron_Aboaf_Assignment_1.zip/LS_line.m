function [ m,b ] = LS_line( x,y )
% LS_line() takes a set of data points and calculates a Linear Least
% Squares regression for the input set of data. The function returns the
% slope and intercept of the best fit line.
% 
% Function call:
% [ m,b ] = LS_line( x,y )
% 
% INPUTS:
% x     = x-axis data as a row vector
% y     = y-axis data
% 
% Written 1/23/2017 -- Aaron Aboaf
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% Calculate A, B, C, and D
A = sum(x);
B = sum(y);
C = sum(x.*y);
D = sum(x.^2);

% Determine the number of data points
N = length(x);

% Calculate the slope, m
m = (A*B - N*C)/(A^2 - N*D);

% Calculate the intercept, b
b = (A*C - B*D)/(A^2 - N*D);

end

