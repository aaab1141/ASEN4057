function [ t_end ] = t_ground( V,theta )
% t_ground() takes the initial airspeed and angle from the horizontal and
% calculates the time at which the projectile will hit the ground. This
% funcition assumes all ideal conditions possible.
% 
% Function call:
% [ t_end ] = t_ground( V,theta )
% 
% INPUTS: (SI units)
% V     = initial projectile speed
% theta = initial projectile angle from the horizontal
% 
% OUTPUTS:
% t_end = time when the projectile hits the ground
% 
% Written - 1/23/2018 - Aaron Aboaf
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Define magnitude of acceleration due to gravity
g = 9.81; %[m/s^2]

% Calculate the time the projectile hits the ground. The equation used is
% the simplified version of the quadratic formula which describes the y
% position of the projectile as a funciton of time.
t_end = 2*V*sin(theta)/g;

end

