function [ air_mass ] = totalair( r,alt )
% totalair() returns the total mass of air displaced by the balloon based
% on the radius of the balloon and the altitude of flight. It also
% considers a varying pressure and temperature of the atmosphere from an
% internal function call.
% 
% Function call:
% [ air_mass ] = totalair( r,alt )
% 
% INPUTS: (assume SI units)
% r     = radius of the balloon
% alt   = altitude of the balloon
% 
% OUTPUTS:
% air_mass = mass of air displaced by the balloon
% 
% Written 1/23/2018 - Aaron Aboaf
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% Calculate the pressure and temperature of air at the input altitude
[ P,T ] = pt_air( alt );

% Calculate the density of air at the input altiude
rho_air = P/(0.2869*(T + 273.15));

% Calculate the mass of the air displaced
air_mass = 4*pi*rho_air*r^3/3;

end

