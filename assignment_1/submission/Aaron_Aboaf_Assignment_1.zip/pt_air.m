function [ P,T ] = pt_air( h )
% pt_air() calculates the pressure and temperature at a given altitude in
% the atmosphere. This atmospheric scale is specific to ASEN 4057
% Assignment 1 Problem 3.
% 
% Function call:
% [ P,T ] = pt_air( h )
% 
% INPUTS:(assume SI units)
% h     = altitude of interest
% 
% OUTPURTS: (assume SI units)
% P     = atmospheric pressure
% T     = atmospheric temperature
% 
% Written 1/23/2018 - Aaron Aboaf
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Set the calculations for P and T based on the input altitude
if h >= 0 && h <= 11000
    T = 15.04 - 0.00649*h;
    P = 101.29*((T+273.15)/288.08)^5.256;
elseif h>11000 && h<=25000
    T = -56.46;
    P = 22.65*exp(1.73 - .000157*h);
elseif h>25000
    T = -131.21 + .00299*h;
    P = 2.488*((T + 273.15)/216.6)^-11.388;
else
    error('Negative Altitude Input to pt_air(...)')
end

end

