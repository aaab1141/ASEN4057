% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% ASEN 4057 -- Assignment #1 -- Problem 3
% 
% This is the main script for Problem 3 which is an application of bouyancy
% in the atmosphere. This script facilitates the solution steps to identify
% the maximum attainable altitude of a given Helium filled weather balloon.
% 
% Written:  Aaron Aboaf   1/23/2017
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Housekeeping
clear; close all; clc

% Define the characteristics of the balloon
r = 3.5; %[m] radius of the balloon
payload = 5; %[kg] payload mass
empty = .6; %[kg] empty balloon mass
mwHe = 4.02; %molecular weight of Helium

% Calculate the maximum altitude the balloon can reach
[ max_altitude ] = altitudemax( r,payload,empty,mwHe );

% Output the maximum altitude to the command window
fprintf('The maximum altitude attained by the balloon is between %6.0f and %6.0f meters.\n',...
    [max_altitude - 10,max_altitude])
