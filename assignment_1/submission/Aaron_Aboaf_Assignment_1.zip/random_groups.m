function [ groups ] = random_groups( names,M )
% random_groups() creates a list of randomized groups for a given number of
% assignments. random_groups() assumes that each group should be 2 people
% and if an odd number of people exist in the given list, then a group of 3
% is created for that assignment. random_groups() will return an error if
% more assignments are input than permutations of groups exist.
%
% Function call:
% [ groups ] = random_groups( names,M )
%
% INPUTS:
% names  = a cell array of strings containing only the names of the
%          students meant to be placed into group pairs. This funciton
%          expects a column vector of names.
% M      = number of assignments
%
% OUTPUTS:
% groups = a cell array containing the pairs for each assignment, or group
%          of three if an odd number of students exists
%
% Written 1/24/2018 - Aaron Aboaf
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% Figure out how many people there are. From this point on, numbers will be
% used to represent people and at the end they will be correlated with the
% names list from the input. Also determine the number of groups there will
% be
N = size(names,1);
if N/2-floor(N/2)~=0 %checks to see if there will be a three person group or not
    num = floor(N/2);
    thirdgroup = 1; %determines the need for a three person group
else
    num = N/2; %number of groups
    thirdgroup = 0; %determines the need for a three preson group
end

% Identify the number of unique combinations possible
combinations = factorial(N)/factorial(N-2)/factorial(2);

if M > combinations %return an
    error('Too many assignments to create unique combinations for each assignment\nfor the number of people.\n')
end

% Build the cell structure for each assignment & preallocate sheets
groups = cell(num+1,3,M);
newsheet = cell(num+1,3);

% Create a vector to represent each person in the group
%people = 1:1:N;

% Create the groups by random assignment while checking for group repetition
status = 0; %set status to "not ok" so that the while loop runs for the next sheet
for i = 1:M
    if i == 1 %the first time around when there are no groups to compare to
        % sort out the first group
        if thirdgroup == 0 %no three person group needed
            newlist = randperm(N); %ransomly mix the names
            row = 2;
            for n = 1:num
                newsheet{row,1} = names{newlist(n)}; %populates first column names
                newsheet{row,2} = names{newlist(n+N/2)}; %populates second column names
                row = row +1;
            end
        else %three person group needed
            newlist = randperm(N); %ransomly mix the names
            row = 2;
            for n = 1:num
                if n < floor(N/2)
                    newsheet{row,1} = names{newlist(n)}; %populates first column names
                    newsheet{row,2} = names{newlist(n+floor(N/2))}; %populates second column names
                    row = row +1;
                    %fprintf('%2.0f,  %2.0f\n',[ n, n+floor(N/2)]) %for debugging
                else
                    newsheet{row,1} = names{newlist(n)}; %populates first column names
                    newsheet{row,2} = names{newlist(n+floor(N/2))}; %populates second column names
                    newsheet{row,3} = names{newlist(n+floor(N/2)+1)}; %populates the last name for the group of three
                    row = row +1;
                end
            end
        end
        groups(:,:,1) = newsheet;
    else %the rest of the groups making sure to compare to see if the groups are repeated
        while status == 0
            % Build the groups randomly
            if thirdgroup == 0 %no three person group needed
                newlist = randperm(N); %ransomly mix the names
                row = 2;
                for n = 1:num
                    newsheet{row,1} = names{newlist(n)}; %populates first column names
                    newsheet{row,2} = names{newlist(n+N/2)}; %populates second column names
                    row = row +1;
                end
            else %three person group needed
                newlist = randperm(N); %ransomly mix the names
                row = 2;
                for n = 1:num
                    if n < floor(N/2)
                        newsheet{row,1} = names{newlist(n)}; %populates first column names
                        newsheet{row,2} = names{newlist(n+floor(N/2))}; %populates second column names
                        row = row +1;
                    else
                        newsheet{row,1} = names{newlist(n)}; %populates first column names
                        newsheet{row,2} = names{newlist(n+floor(N/2))}; %populates second column names
                        newsheet{row,3} = names{newlist(n+floor(N/2)+1)}; %populates the last name for the group of three
                        row = row +1;
                    end
                end
            end
            status = checker(groups,newsheet); %check if unique groups exist
        end
        groups(:,:,i) = newsheet;
    end
    status = 0; %reset status variable to run the while loop again
    % assign the approved groups to the group list
end
% Label each cell sheet with the Assignment number
for i = 1:M
    groups{1,1,i} = ['Assignment ',num2str(i);];
end
end

function [ yn ] = checker( old, new )
% compares the groups to ensure uniqueness among groups
% old matrix should include all the previous layers
% new should just be the new layer
insight = zeros(size(old,1),1); %holds the "logical" values for each group
for k = 1:size(old,3) %each previous group assignment
    for j = 2:size(old,1) %each group check
        if j < size(old,1)
            a = double(strcmp(old{j,1,k},new{j,1}));
            b = double(strcmp(old{j,2,k},new{j,1}));
            c = double(strcmp(old{j,2,k},new{j,2}));
            if a+b+c > 1 %means that both names showed up in the same group
                insight(j) = insight(j)+1;
                %fprintf('duplicate group encountered\n') %for debugging
            else
                insight(j) = 0;
            end
        elseif isempty(old{j,3,k}) == 1 %last row is a pair special case
            a = double(strcmp(old{j,1,k},new{j,1}));
            b = double(strcmp(old{j,2,k},new{j,1}));
            c = double(strcmp(old{j,2,k},new{j,2}));
            if a+b+c > 1 %means that both names showed up in the same group
                insight(j) = insight(j)+1;
                %fprintf('duplicate group encountered\n') %for debugging
            else
                insight(j) = 0;
            end
        else %last row is a group of three special case
            a = double(strcmp(old{j,1,k},new{j,1}));
            b = double(strcmp(old{j,2,k},new{j,1}));
            c = double(strcmp(old{j,3,k},new{j,1}));
            d = double(strcmp(old{j,2,k},new{j,2}));
            e = double(strcmp(old{j,3,k},new{j,2}));
            f = double(strcmp(old{j,3,k},new{j,3}));
            if a+b+c+d+e+f > 2 %means that both names showed up in the same group
                insight(j) = insight(j)+1;
                %fprintf('duplicate group encountered\n') %for debugging
            else
                insight(j) = 0;
            end
        end
    end
end
if sum(insight) == 0
    yn = 1; %the new list is completely different from any old list
else
    yn = 0; %the new list has at least one identical pair as an old list
end
end

