% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% ASEN 4057 -- Assignment #1 -- Problem BONUS
% 
% This is the main script for the BONUS problem. This script facilitates
% the initial conditions for a customized function which creates assignment
% pairings for N students and M assignments. 
% 
% Written:  Aaron Aboaf   1/24/2017 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Housekeeping
clear; close all; clc

% Define names of students and number of assignments
names = {'Aboaf Aaron';'Alec Viets';'Ankit Hriday';'Aubrey Mckelvy';'Benjamin Elsaesser';...
    'Benjamin Spencer';'Braden Solt';'Brandon Stetler';'Brandon Sundahl';...
    'Brindan Adhikari';'Chase Pellazar';'Connie Childs';'Connor Kerry';'Connor Ott';...
    'Daniel Mastick';'David Kain';'Eric Zhao';'Iris Altman';'Joey Beightol';...
    'Justin Fay';'Keith Covington';'Kennedy Harrmann';'Lara Lufkin';'Lucas Sorensen';...
    'Madison Junker';'Michael Labarge';'Michael Tzimourakas';'Nicholas Moore';...
    'Nolan Lee';'Quentin Moore';'Robert Hakulin';'Ross Kloetzel';'Ryan Stewart';...
    'Sergey Derevyanko';'Torfinn Johnsrud';'Yao Shen'};%names of students
M = 10; %number of assignments

% Create the randomized groups
groups = random_groups( names,M );



