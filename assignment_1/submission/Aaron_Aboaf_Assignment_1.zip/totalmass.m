function [ total_mass ] = totalmass( r,payload,empty,mwGas )
% totalmass() calculates and returns the total mass of a weather balloon
% given the input values described below.
% 
% Function call:
% [ total_mass ] = totalmass( r,payload,empty,mwGas )
% 
% INPUTS: (assumes consistent units)
% r     = radius of the balloon
% pw    = mass of the payload
% empty = mass of the empty balloon
% mwGas = molecular weight of the lifting gas
% 
% OUTPUTS:
% total_mass = total mass of the balloon system
% 
% Written 1/23/2018 - Aaron Aboaf
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Calculate the mass of the lifting gas
mGas = (4*pi*1.225*r^3*mwGas)/(3*28.966);

% Calculate the total mass of the balloon system
total_mass = mGas + payload + empty;

end

