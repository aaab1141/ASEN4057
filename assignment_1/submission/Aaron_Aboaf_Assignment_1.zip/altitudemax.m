function [ max_altitude ] = altitudemax( r,payload,empty,mwGas )
% altitudemax() calculates the maximum attainable altitude of a rigid
% balloon based on the input criteria deacribed below. Assume all imputs
% and outputs to be in conistent units (SI recommended). Also Assume the
% balloon always starts at sea level.
% 
% Function call:
% [ max_altitude ] = altitudemax( r,payload,empty,mwGas )
% 
% INPUTS: (assumes consistent units)
% r     = radius of the balloon
% pw    = mass of the payload
% empty = mass of the empty balloon
% mwGas = molecular weight of the lifting gas
% 
% OUTPUTS:
% max_altitude = maximum altitude attained by the rigid balloon. Will be to
% the nearest 10 length unit increment
% 
% Written 1/23/2018 - Aaron Aboaf
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Calculate the total mass of the balloon - constant for the application
[ total_mass ] = totalmass( r,payload,empty,mwGas );

% Calculate the initial total mass of the air displaced
alt = 0; %Sea Level altitude - we assume the balloon always starts here
[ air_mass ] = totalair( r,alt );

% Calculate the maximum altitude using a while loop to set the mass
% condition such that the loop stops executing when the balloon mass is
% larger than the air mass displaced
while total_mass < air_mass
    alt = alt + 10; %increment the altitude
    
    % Calculate the new total mass of the air displaced at the new altitude
    [ air_mass ] = totalair( r,alt );
end

% Set the maximum altitude as the output
max_altitude = alt;

end

