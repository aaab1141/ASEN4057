% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% ASEN 4057 -- Assignment #1 -- Problem 1
% 
% This is the main script for Problem 1 which is the projectile motion with
% an initial airspeed. This script facilitates the solution to the problem
% posed using generalized functions.
% 
% Written:  Aaron Aboaf   1/23/2017 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Housekeeping
clear; close all; clc

% Definitions
g = 9.81; %m/s^2 magnitude of gravitational acceleration

% Prompt the user for the required inputs
prompt = {'Angle from the Horizontal: \theta (^o)','Initial Speed (m/s)'};
name = 'User Inputs:';
options.Interpreter = 'tex';
d_ans = {'45','20'};
inputs = inputdlg(prompt,name,1,d_ans,options);

% Extract the inputs from the cell array
theta = str2double(inputs{1})*pi/180;
V = str2double(inputs{2});

% Find the time when the projectile hits the ground
t_end = t_ground(V,theta);

% Create the data points of the trajectory for plotting
t = linspace(0,t_end,100); %time vector from t=0 to t=t_end
x = V*cos(theta)*t; %x positions
y = -1/2*g*t.^2 + V*sin(theta)*t; %y positions

% Plot the trajectory
figure
plot(x,y); grid on
title('Projectile Trajectory')
xlabel('Horizontal Position (m)')
ylabel('Vertical Position (m)')
